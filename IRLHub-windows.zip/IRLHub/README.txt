IRL Hub 0.3.0

Keep the nginx folder next to IRLHub.exe. Run IRLHub.exe: it opens its
dashboard in your browser and lives in the system tray.

nginx-rtmp-win32 (nginx\nginx.exe) is BSD-licensed; see nginx\LICENSE.
